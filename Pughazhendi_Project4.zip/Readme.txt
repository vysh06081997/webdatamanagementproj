****USERNAME AND PASSWORD FOR ADMIN AND CUSTOMER ****


****ADMIN****
Username : vysali
Password : vysalipughaz


****CUSTOMER****
Username : diyag
Password : diyaistalking